<?php include '../auth.php'; include '../config.php'; if($_SESSION['role']!='santri'){header('Location: ../login.php');exit;} ?>
<h2>Status Perizinan</h2><p>Fitur perizinan belum aktif.</p>