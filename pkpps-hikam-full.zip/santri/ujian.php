<?php include '../auth.php'; include '../config.php'; if($_SESSION['role']!='santri'){header('Location: ../login.php');exit;} ?>
<h2>Ujian Online (Sederhana)</h2>
<p>Belum ada soal. Hubungi guru.</p>