<?php include '../auth.php'; include '../config.php'; if($_SESSION['role']!='santri'){header('Location: ../login.php');exit;} ?>
<h2>Dashboard Santri</h2>
<p>Halo, <?php echo htmlspecialchars($_SESSION['nama']); ?></p>
<ul><li><a href="ujian.php">Ikut Ujian</a></li><li><a href="perizinan.php">Status Perizinan</a></li><li><a href="../logout.php">Logout</a></li></ul>