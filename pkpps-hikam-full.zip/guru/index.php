<?php include '../auth.php'; include '../config.php'; if($_SESSION['role']!='guru'){header('Location: ../login.php');exit;} ?>
<h2>Dashboard Guru</h2>
<p>Selamat datang, <?php echo htmlspecialchars($_SESSION['nama']); ?></p>
<ul><li><a href="nilai_input.php">Input Nilai</a></li><li><a href="nilai_view.php">Lihat Nilai</a></li><li><a href="../logout.php">Logout</a></li></ul>