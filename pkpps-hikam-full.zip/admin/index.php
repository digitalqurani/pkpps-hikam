<?php include '../auth.php'; if($_SESSION['role']!='admin') { header('Location: ../login.php'); exit; } ?>
<h2>Admin Dashboard</h2>
<p>Selamat datang, <?php echo htmlspecialchars($_SESSION['nama']); ?></p>
<ul>
<li><a href="users.php">Kelola User</a></li>
<li><a href="santri.php">Data Santri</a></li>
<li><a href="jadwal.php">Jadwal</a></li>
<li><a href="../logout.php">Logout</a></li>
</ul>