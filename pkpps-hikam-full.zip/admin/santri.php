<?php include '../auth.php'; include '../config.php'; if($_SESSION['role']!='admin'){header('Location: ../login.php');exit;} ?>
<h2>Data Santri</h2>
<?php
if(isset($_POST['add'])){
    $n=$_POST['nama']; $k=$_POST['kelas']; $w=$_POST['wali'];
    $ins=mysqli_prepare($conn,'INSERT INTO santri(nama,kelas,kamar,wali) VALUES(?,?,?,?)');
    mysqli_stmt_bind_param($ins,'ssss',$n,$k,$_POST['kamar'],$w); mysqli_stmt_execute($ins);
}
$res=mysqli_query($conn,'SELECT * FROM santri');
echo '<table><tr><th>ID</th><th>Nama</th><th>Kelas</th><th>Wali</th></tr>';
while($r=mysqli_fetch_assoc($res)) echo '<tr><td>'.$r['id'].'</td><td>'.$r['nama'].'</td><td>'.$r['kelas'].'</td><td>'.$r['wali'].'</td></tr>';
echo '</table>';
?>
<h3>Tambah Santri</h3>
<form method="post"><input name="nama" required><input name="kelas" required><input name="kamar"><input name="wali"><button name="add">Tambah</button></form>