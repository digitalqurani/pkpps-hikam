<?php include '../auth.php'; include '../config.php'; if($_SESSION['role']!='admin'){header('Location: ../login.php');exit;} ?>
<h2>Kelola User</h2>
<?php
if(isset($_POST['add'])){
    $u=$_POST['username']; $p=password_hash($_POST['password'],PASSWORD_DEFAULT); $r=$_POST['role']; $n=$_POST['nama'];
    $ins=mysqli_prepare($conn,'INSERT INTO users(username,password,role,nama_lengkap) VALUES(?,?,?,?)');
    mysqli_stmt_bind_param($ins,'ssss',$u,$p,$r,$n); mysqli_stmt_execute($ins);
}
$res=mysqli_query($conn,'SELECT id,username,role,nama_lengkap FROM users');
echo '<table><tr><th>ID</th><th>Username</th><th>Nama</th><th>Role</th></tr>';
while($row=mysqli_fetch_assoc($res)){
    echo '<tr><td>'.$row['id'].'</td><td>'.$row['username'].'</td><td>'.$row['nama_lengkap'].'</td><td>'.$row['role'].'</td></tr>';
}
echo '</table>';
?>
<h3>Tambah User</h3>
<form method="post">
<input name="nama" placeholder="Nama Lengkap" required><br>
<input name="username" placeholder="username" required><br>
<input name="password" placeholder="password" required><br>
<select name="role"><option value="admin">admin</option><option value="guru">guru</option><option value="santri">santri</option></select><br>
<button name="add">Tambah</button>
</form>